//first stepper motor
#define STEP_PIN_1 15
#define DIR_PIN_1 14
#define ENABLE_PIN_1 19   

#define M0_PIN_1 18    
#define M1_PIN_1 17
#define M2_PIN_1 16

// first dc motor
#define PWM1 2
#define DIR1 3

//second stepper motor
#define STEP_PIN_2 24
#define DIR_PIN_2 22
#define ENABLE_PIN_2 32

#define M0_PIN_2 30 
#define M1_PIN_2 28
#define M2_PIN_2 26

// second dc motor
#define PWM2 4
#define DIR2 5

//third stepper motor
#define STEP_PIN_3 25
#define DIR_PIN_3 23
#define ENABLE_PIN_3 33 

#define M0_PIN_3 31 
#define M1_PIN_3 29
#define M2_PIN_3 27

// third dc motor
#define PWM3 6
#define DIR3 7


//fourth stepper motor
#define STEP_PIN_4 39
#define DIR_PIN_4 37
#define ENABLE_PIN_4 47

#define M0_PIN_4 41
#define M1_PIN_4 43
#define M2_PIN_4 45

// fourth dc motor
#define PWM4 8
#define DIR4 9

#define STEP_ANGLE_DEFAULT 0.9
#define MAX_ANGLE 90
#define MIN_ANGLE -90

int in1 = 11;
int in2 = 10;

int currentAngle = 0;
int mode = 0;
float STEP_ANGLE = STEP_ANGLE_DEFAULT;

unsigned long lastPrintTime = 0;
const unsigned long printInterval = 2500;
  
int resolution = 32; // It takes 1,2,4,8,16,32
int delay_time = 500;

int led1 = 12;
int led2 = 13;

void setup() {
  Serial.begin(9600);
  //first stepper
  pinMode(STEP_PIN_1, OUTPUT);
  pinMode(DIR_PIN_1, OUTPUT);
  pinMode(ENABLE_PIN_1, OUTPUT);

  pinMode(M0_PIN_1, OUTPUT);
  pinMode(M1_PIN_1, OUTPUT);
  pinMode(M2_PIN_1, OUTPUT);
  //second stpper
  pinMode(STEP_PIN_2, OUTPUT);
  pinMode(DIR_PIN_2, OUTPUT);
  pinMode(ENABLE_PIN_2, OUTPUT);

  pinMode(M0_PIN_2, OUTPUT);
  pinMode(M1_PIN_2, OUTPUT);
  pinMode(M2_PIN_2, OUTPUT);

  //third stpper
  pinMode(STEP_PIN_3, OUTPUT);
  pinMode(DIR_PIN_3, OUTPUT);
  pinMode(ENABLE_PIN_3, OUTPUT);

  pinMode(M0_PIN_3, OUTPUT);
  pinMode(M1_PIN_3, OUTPUT);
  pinMode(M2_PIN_3, OUTPUT);

  //fourth stpper
  pinMode(STEP_PIN_4, OUTPUT);
  pinMode(DIR_PIN_4, OUTPUT);
  pinMode(ENABLE_PIN_4, OUTPUT);

  pinMode(M0_PIN_4, OUTPUT);
  pinMode(M1_PIN_4, OUTPUT);
  pinMode(M2_PIN_4, OUTPUT);

  pinMode(PWM1,OUTPUT);
  pinMode(DIR1,OUTPUT);
  pinMode(PWM2,OUTPUT);
  pinMode(DIR2,OUTPUT);
  pinMode(PWM3,OUTPUT);
  pinMode(DIR3,OUTPUT);
  pinMode(PWM4,OUTPUT);
  pinMode(DIR4,OUTPUT);

  digitalWrite(M0_PIN_1, HIGH);
  digitalWrite(M1_PIN_1, HIGH);
  digitalWrite(M2_PIN_1, HIGH);

  digitalWrite(M0_PIN_2, HIGH);
  digitalWrite(M1_PIN_2, HIGH);
  digitalWrite(M2_PIN_2, HIGH);

  digitalWrite(M0_PIN_3, HIGH);
  digitalWrite(M1_PIN_3, HIGH);
  digitalWrite(M2_PIN_3, HIGH);

  digitalWrite(M0_PIN_4, HIGH);
  digitalWrite(M1_PIN_4, HIGH);
  digitalWrite(M2_PIN_4, HIGH);

  digitalWrite(ENABLE_PIN_1, LOW);
  digitalWrite(ENABLE_PIN_2, LOW);
  digitalWrite(ENABLE_PIN_3, LOW);  
  digitalWrite(ENABLE_PIN_4, LOW); 

  digitalWrite(DIR_PIN_1, HIGH);
  digitalWrite(DIR_PIN_2, HIGH); 
  digitalWrite(DIR_PIN_3, HIGH);
  digitalWrite(DIR_PIN_4, HIGH);  

  pinMode(in1,OUTPUT);
  pinMode(in2,OUTPUT);
  digitalWrite(in1,LOW);
  digitalWrite(in2,HIGH);

  pinMode(led1,OUTPUT);
  pinMode(led2,OUTPUT);
  digitalWrite(led1,LOW);
  digitalWrite(led2,HIGH);
}
int i = 0;
int remaining_steps = 0;
int orientation = HIGH;
bool motor_enabled = false;
float traveled_angle = 0;
int real_angle = 0;
int robot_state = 0;
int elevate_systeme = 0;

void loop() {
  if (Serial.available() > 0) {
    String msg = Serial.readStringUntil('\n');
    int commaIndex1 = msg.indexOf(',');
    int commaIndex2 = msg.indexOf('#');
    int commaIndex3 = msg.indexOf('!');
    int commaIndex4 = msg.indexOf('@');
    int commaIndex5 = msg.indexOf('$');

    if (commaIndex1 != -1 && commaIndex2 != -1 && commaIndex3 != -1) {
      String angleString = msg.substring(0, commaIndex1);
      String pwmString = msg.substring(commaIndex1+1, commaIndex2);
      String directionString = msg.substring(commaIndex2+1, commaIndex3);
      String modeString = msg.substring(commaIndex3+1,commaIndex4);
      String robot_stateString = msg.substring(commaIndex4+1,commaIndex5);
      String elevate_systemeString = msg.substring(commaIndex5+1);


      int angle = angleString.toInt();
      int pwm = pwmString.toInt();
      int direction = directionString.toInt();
      robot_state = robot_stateString.toInt();
      elevate_systeme = elevate_systemeString.toInt();

      mode = modeString.toInt();
      if (robot_state == 1){
        digitalWrite(led1,HIGH);
        digitalWrite(led2,LOW);
      }else{
        digitalWrite(led1,LOW);
        digitalWrite(led2,HIGH);
      }
      switch (resolution) {
        case 1: no_MicroStep(); break;
        case 2: two_MicroStep(); break;
        case 4: for_MicroStep(); break;
        case 8: eight_MicroStep(); break;
        case 16: sextyne_MicroStep(); break;
        case 32: thirty_two_MicroStep(); break;
        default: STEP_ANGLE = 0;
      }
      real_angle = limit_angle(angle, traveled_angle);
      remaining_steps = abs(converte_angleTostep(real_angle, STEP_ANGLE));
      orientation = (real_angle > 0) ? HIGH : LOW;
      motor_enabled = true;
      mouve_motors(pwm, direction);  
    }
  }

  // Stepper movement (non-blocking)
  if (motor_enabled && remaining_steps > 0 && mode == 0) {
    digitalWrite(ENABLE_PIN_1, LOW);
    digitalWrite(ENABLE_PIN_2, LOW);

    digitalWrite(DIR_PIN_1, orientation);
    digitalWrite(DIR_PIN_2, orientation);


    digitalWrite(STEP_PIN_1, HIGH);
    digitalWrite(STEP_PIN_2, HIGH);
    delayMicroseconds(delay_time);

    digitalWrite(STEP_PIN_1, LOW);
    digitalWrite(STEP_PIN_2, LOW);
    delayMicroseconds(delay_time);
    if (real_angle > 0){
      traveled_angle += (STEP_ANGLE/2);
    }
    else{
      traveled_angle -= (STEP_ANGLE/2);
    }
    remaining_steps--;
  }
  else if (motor_enabled && remaining_steps > 0 && mode == 1) {
    digitalWrite(ENABLE_PIN_1, LOW);
    digitalWrite(ENABLE_PIN_2, LOW);
    digitalWrite(ENABLE_PIN_3, LOW);
    digitalWrite(ENABLE_PIN_4, LOW);

    digitalWrite(DIR_PIN_1, orientation);
    digitalWrite(DIR_PIN_2, orientation);
    digitalWrite(DIR_PIN_3, orientation);
    digitalWrite(DIR_PIN_4, orientation);

    digitalWrite(STEP_PIN_1, HIGH);
    digitalWrite(STEP_PIN_2, HIGH);
    digitalWrite(STEP_PIN_3, HIGH);
    digitalWrite(STEP_PIN_4, HIGH);
    delayMicroseconds(delay_time);

    digitalWrite(STEP_PIN_1, LOW);
    digitalWrite(STEP_PIN_2, LOW);
    digitalWrite(STEP_PIN_3, LOW);
    digitalWrite(STEP_PIN_4, LOW);
    delayMicroseconds(delay_time);
    if (real_angle > 0){
      traveled_angle += (STEP_ANGLE/2);
    }
    else{
      traveled_angle -= (STEP_ANGLE/2);
    }
    
    remaining_steps--;

    if (robot_state == 1){
      digitalWrite(led1,HIGH);
      digitalWrite(led2,LOW);
    }
    else{
      digitalWrite(led1,LOW);
      digitalWrite(led2,HIGH);  
    }
  }

  if (remaining_steps == 0) {
    digitalWrite(ENABLE_PIN_1, HIGH);
    digitalWrite(ENABLE_PIN_2, HIGH);
    motor_enabled = false;
  }
  if (robot_state == 1){
    if (mode == 0){
      digitalWrite(ENABLE_PIN_3, LOW);
      digitalWrite(ENABLE_PIN_4, LOW);
    }
    else{
      digitalWrite(ENABLE_PIN_1, LOW);
      digitalWrite(ENABLE_PIN_2, LOW);
      digitalWrite(ENABLE_PIN_3, LOW);
      digitalWrite(ENABLE_PIN_4, LOW);
    }
  }else{
    digitalWrite(ENABLE_PIN_1, HIGH);
    digitalWrite(ENABLE_PIN_2, HIGH);
    digitalWrite(ENABLE_PIN_3, HIGH);
    digitalWrite(ENABLE_PIN_4, HIGH);
  }
  if (elevate_systeme == 1){
    digitalWrite(in1,HIGH);
    digitalWrite(in2,LOW);
  }else{
    digitalWrite(in1,LOW);
    digitalWrite(in2,HIGH);
  }
  
}


int limit_angle(int command_angle, int current_angle) {
    int output_angle = command_angle - current_angle; 

    
    int new_angle = current_angle + output_angle;

    if (new_angle > MAX_ANGLE) {
        output_angle = MAX_ANGLE - current_angle;
    } 
    else if (new_angle < MIN_ANGLE) {
        output_angle = MIN_ANGLE - current_angle;
    }

    current_angle += output_angle; 
    return output_angle; 
}
int converte_angleTostep(int angle,float STEP_ANGLE){
  return (angle*2)/STEP_ANGLE;
}


void mouve_motors(int speed,int dir){
  if (mode == 0 ){
    if (dir == 0){
    digitalWrite(DIR1,LOW);
    digitalWrite(DIR2,LOW);
    digitalWrite(DIR3,LOW);
    digitalWrite(DIR4,LOW);
    }
    else if (dir == 1){
      digitalWrite(DIR1,HIGH);
      digitalWrite(DIR2,HIGH);
      digitalWrite(DIR3,HIGH);
      digitalWrite(DIR4,HIGH);
    }
    analogWrite(PWM1,speed);
    analogWrite(PWM2,speed);
    analogWrite(PWM3,speed);
    analogWrite(PWM4,speed);
  }
  else if (mode == 1){
    if (dir == 0){
    digitalWrite(DIR1,HIGH);
    digitalWrite(DIR2,HIGH);
    digitalWrite(DIR3,LOW);
    digitalWrite(DIR4,LOW);
    }
    else if (dir == 1){
      digitalWrite(DIR1,LOW);
      digitalWrite(DIR2,LOW);
      digitalWrite(DIR3,HIGH);
      digitalWrite(DIR4,HIGH);
    }
    analogWrite(PWM1,speed);
    analogWrite(PWM2,speed);
    analogWrite(PWM3,speed);
    analogWrite(PWM4,speed);
  }
}

void no_MicroStep(){
  digitalWrite(M0_PIN_1, LOW);
  digitalWrite(M1_PIN_1, LOW);
  digitalWrite(M2_PIN_1, LOW);

  digitalWrite(M0_PIN_2, LOW);
  digitalWrite(M1_PIN_2, LOW);
  digitalWrite(M2_PIN_2, LOW);

  digitalWrite(M0_PIN_3, LOW);
  digitalWrite(M1_PIN_3, LOW);
  digitalWrite(M2_PIN_3, LOW);
  STEP_ANGLE = 1.8;
}

// Set 2 microsteps (Half Step)
void two_MicroStep(){
  digitalWrite(M0_PIN_1, HIGH);
  digitalWrite(M1_PIN_1, LOW);
  digitalWrite(M2_PIN_1, LOW);

  digitalWrite(M0_PIN_2, HIGH);
  digitalWrite(M1_PIN_2, LOW);
  digitalWrite(M2_PIN_2, LOW);

  digitalWrite(M0_PIN_3, HIGH);
  digitalWrite(M1_PIN_3, LOW);
  digitalWrite(M2_PIN_3, LOW);
  STEP_ANGLE = 0.9;
}

// Set 4 microsteps
void for_MicroStep(){
  digitalWrite(M0_PIN_1, LOW);
  digitalWrite(M1_PIN_1, HIGH);
  digitalWrite(M2_PIN_1, LOW);

  digitalWrite(M0_PIN_2, LOW);
  digitalWrite(M1_PIN_2, HIGH);
  digitalWrite(M2_PIN_2, LOW);

  digitalWrite(M0_PIN_3, LOW);
  digitalWrite(M1_PIN_3, HIGH);
  digitalWrite(M2_PIN_3, LOW);
  STEP_ANGLE = 0.45;
}

// Set 8 microsteps
void eight_MicroStep(){
  digitalWrite(M0_PIN_1, HIGH);
  digitalWrite(M1_PIN_1, HIGH);
  digitalWrite(M2_PIN_1, LOW);

  digitalWrite(M0_PIN_2, HIGH);
  digitalWrite(M1_PIN_2, HIGH);
  digitalWrite(M2_PIN_2, LOW);

  digitalWrite(M0_PIN_3, HIGH);
  digitalWrite(M1_PIN_3, HIGH);
  digitalWrite(M2_PIN_3, LOW);
  STEP_ANGLE = 0.225; 
}

// Set 16 microsteps
void sextyne_MicroStep(){
  digitalWrite(M0_PIN_1, LOW);
  digitalWrite(M1_PIN_1, LOW);
  digitalWrite(M2_PIN_1, HIGH);

  digitalWrite(M0_PIN_2, LOW);
  digitalWrite(M1_PIN_2, LOW);
  digitalWrite(M2_PIN_2, HIGH);

  digitalWrite(M0_PIN_3, LOW);
  digitalWrite(M1_PIN_3, LOW);
  digitalWrite(M2_PIN_3, HIGH);
  STEP_ANGLE = 0.1125; 
}

// Set 32 microsteps
void thirty_two_MicroStep(){
  digitalWrite(M0_PIN_1, HIGH);
  digitalWrite(M1_PIN_1, HIGH);
  digitalWrite(M2_PIN_1, HIGH);

  digitalWrite(M0_PIN_2, HIGH);
  digitalWrite(M1_PIN_2, HIGH);
  digitalWrite(M2_PIN_2, HIGH);

  digitalWrite(M0_PIN_3, HIGH);
  digitalWrite(M1_PIN_3, HIGH);
  digitalWrite(M2_PIN_3, HIGH);
  STEP_ANGLE = 0.05625; 
}