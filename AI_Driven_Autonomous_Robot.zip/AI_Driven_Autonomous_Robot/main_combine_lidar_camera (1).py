import cv2
import numpy as np
import serial.tools.list_ports
import threading
import tkinter as tk
from tkinter import ttk
import matplotlib
matplotlib.use('Agg') 
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from rplidar import RPLidar
from matplotlib.patches import Polygon, Circle
import time

ports = serial.tools.list_ports.comports()
serialInst = serial.Serial()
serialInst.baudrate = 9600
serialInst.port = "COM6"
serialInst.open()

cap = cv2.VideoCapture(1)
dispW, dispH = 640, 480
cap.set(cv2.CAP_PROP_FRAME_WIDTH, dispW)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, dispH)

low = (32, 50, 61)
high = (90, 255, 255)

robot_running = False
show_filtered = False
show_mask = False
show_camera = True
elevated = False
first_start_robot = True
avoiding_obstacle = False

selected_depot = 1
robot_state = 0
elevate_systeme = 0
angle = 0
last_seen_angle = 0

OBSTACLE_DISTANCE_THRESHOLD = 850 
AVOIDANCE_ANGLE = 35  
AVOIDANCE_PWM = 190
PWM = 190

def process_video():
    global robot_running, show_filtered, show_mask, low, high, elevate_systeme,avoiding_obstacle, last_seen_angle,angle,first_start_robot
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break

        hsv_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv_frame, low, high)
        filtered = cv2.bitwise_and(frame, frame, mask=mask)

        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if robot_running and len(contours) > 0:
            largest_contour = max(contours, key=cv2.contourArea)
            area = cv2.contourArea(largest_contour)
            if area > 500:
                cv2.drawContours(frame, [largest_contour], 0, (255, 0, 0), 3)
                M = cv2.moments(largest_contour)
                if M["m00"] != 0:
                    cx = int(M["m10"] / M["m00"])
                    cy = int(M["m01"] / M["m00"])
                    cv2.circle(frame, (cx, cy), 5, (0, 255, 0), -1)
                    coord_text = f"Cx: {cx}, Cy: {cy}"
                    cv2.putText(frame, coord_text, (10,465),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
                    area_text = f"{area} Pixels"
                    cv2.putText(frame, area_text, (470,465),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
                    angle = int(np.interp(cx, [0, 640], [-40, 40]))
                    object_detected = True
                    last_seen_angle = angle
                    first_start_robot = False
                else:
                    object_detected = False
            else:
                object_detected = False

            left_min = 9999
            right_min = 9999
            front_min = 9999
            for i, point in enumerate(lidar_visualizer.scan_points):
                x, y = point
                if 0 <= y <= 1000:  
                    if -5 <= x <= 5:
                        front_min = min(front_min, lidar_visualizer.distances[i])
                    elif -210 < x < -5:
                        left_min = min(left_min, lidar_visualizer.distances[i])
                    elif 5 < x < 210:
                        right_min = min(right_min, lidar_visualizer.distances[i])

            if object_detected:
                if (front_min < OBSTACLE_DISTANCE_THRESHOLD or left_min < OBSTACLE_DISTANCE_THRESHOLD or right_min < OBSTACLE_DISTANCE_THRESHOLD):
                    if (front_min < 200 or area > 100000):
                        print("Front Min < 200")
                        data = f"{angle},0#0!0@{robot_state}${elevate_systeme}\n"

                    elif ((front_min < 500 and  left_min < 500 and right_min < 500) or ( left_min < 500 and right_min < 500)):
                        print("Obsctacle detected")
                        data = f"{angle},0#0!0@{robot_state}${elevate_systeme}\n"

                    elif right_min > left_min:
                        # Obstacle is more on the left → turn right
                        data = f"{AVOIDANCE_ANGLE},{AVOIDANCE_PWM}#0!0@{robot_state}${elevate_systeme}\n"
                        print("(Object Detected) Avoiding: Obstacle ahead → turning right")
                    else:
                        # Obstacle is more on the right → turn left
                        data = f"{-AVOIDANCE_ANGLE},{AVOIDANCE_PWM}#0!0@{robot_state}${elevate_systeme}\n"
                        print("(Object Detected) Avoiding: Obstacle ahead → turning left")
                else: 
                    data = f"{angle},{PWM}#0!0@{robot_state}${elevate_systeme}\n"
                    print(f"(Object Detected) Tracking object → angle: {angle}, pwm: {PWM}")
                
            else:
                if first_start_robot:
                    data = f"0,0#0!0@{robot_state}${elevate_systeme}\n"
                else:
                    if (front_min < OBSTACLE_DISTANCE_THRESHOLD or left_min < OBSTACLE_DISTANCE_THRESHOLD or right_min < OBSTACLE_DISTANCE_THRESHOLD):
                        if (front_min < 200):
                            print("Front Min < 200")
                            data = f"{angle},0#0!0@{robot_state}${elevate_systeme}\n"

                        elif ((front_min < 500 and  left_min < 500 and right_min < 500) or ( left_min < 500 and right_min < 500)):
                            print("Obsctacle detected")
                            data = f"{angle},0#0!0@{robot_state}${elevate_systeme}\n"
                        elif right_min > left_min:
                            # Obstacle is more on the left → turn right
                            data = f"{AVOIDANCE_ANGLE},{AVOIDANCE_PWM}#0!0@{robot_state}${elevate_systeme}\n"
                            print("(Object Not Detected) Avoiding: Obstacle ahead → turning right")
                        else:
                            # Obstacle is more on the right → turn left
                            data = f"{-AVOIDANCE_ANGLE},{AVOIDANCE_PWM}#0!0@{robot_state}${elevate_systeme}\n"
                            print("(Object Not Detected) Avoiding: Obstacle ahead → turning left")
                    else: 
                        data = f"{last_seen_angle},{PWM}#0!0@{robot_state}${elevate_systeme}\n"
                        print(f"(Object Not Detected) Tracking object → angle: {angle}, pwm: {PWM}")
                
            serialInst.write(data.encode('utf-8'))

        # Draw overlays
        center_x, center_y = dispW // 2, dispH // 2
        cv2.circle(frame, (center_x, center_y), 5, (0, 0, 255), -1)
        cv2.rectangle(frame, (center_x - 300, center_y - 200), (center_x + 300, center_y + 200), (0, 255, 255), 4)
        cv2.rectangle(frame, (center_x - 82, center_y - 65), (center_x + 82, center_y + 65), (0, 255, 0), 4)

        if show_camera:
            cv2.imshow("Frame", frame)
            cv2.moveWindow("Frame", 660, 100)
        elif cv2.getWindowProperty("Frame", cv2.WND_PROP_VISIBLE) >= 1:
            cv2.destroyWindow("Frame")

        if show_filtered:
            cv2.imshow("Filtered", filtered)
        elif cv2.getWindowProperty("Filtered", cv2.WND_PROP_VISIBLE) >= 1:
            cv2.destroyWindow("Filtered")

        if cv2.waitKey(1) == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()


# --------------------------- LIDAR PROCESS ----------------------------
ROBOT_LENGTH = 600  # mm
ROBOT_WIDTH = 400   # mm
LIDAR_OFFSET_X = 0
LIDAR_OFFSET_Y = ROBOT_LENGTH / 2 - 100  # 100 mm from front

def rotate(coords, angle_deg):
    angle_rad = np.deg2rad(angle_deg)
    R = np.array([
        [np.cos(angle_rad), -np.sin(angle_rad)],
        [np.sin(angle_rad),  np.cos(angle_rad)]
    ])
    return coords @ R.T

def add_robot_patch(ax):
    half_length = ROBOT_LENGTH / 2
    half_width = ROBOT_WIDTH / 2
    corners = np.array([
        [-half_width, -half_length],
        [-half_width,  half_length],
        [ half_width,  half_length],
        [ half_width, -half_length],
    ])
    return Polygon(corners, closed=True, edgecolor='red', facecolor='none', linewidth=2)

class LidarVisualizer:
    def __init__(self, root):
        self.root = root
        self.fig, self.ax = plt.subplots(figsize=(6, 6))
        self.ax.set_aspect('equal')
        # Increased range to 4000mm
        self.ax.set_xlim(-4000, 4000)
        self.ax.set_ylim(-4000, 4000)
        
        # Updated grid lines for new range
        for x in range(-4000, 4001, 1000):
            self.ax.axvline(x=x, color='lightgray', linestyle='--', linewidth=0.5)
        for y in range(-4000, 4001, 1000):
            self.ax.axhline(y=y, color='lightgray', linestyle='--', linewidth=0.5)
            
        self.robot_patch = add_robot_patch(self.ax)
        self.ax.add_patch(self.robot_patch)
        
        self.lidar_dot = Circle((0, 0), 50, color='blue')
        self.ax.add_patch(self.lidar_dot)
        
        # Updated scatter plot with new range
        self.points_scatter = self.ax.scatter([], [], s=5, c=[], cmap='jet', vmin=0, vmax=4000)
        
        self.canvas = FigureCanvasTkAgg(self.fig, master=root)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        
        self.robot_theta = 0
        self.robot_pos = -rotate(np.array([[LIDAR_OFFSET_X, LIDAR_OFFSET_Y]]), self.robot_theta)[0]
        self.scan_points = []
        self.distances = []
        
        self.running = True
        self.thread = threading.Thread(target=self.update_lidar)
        self.thread.daemon = True
        self.thread.start()
    
    def update_lidar(self):
        lidar = RPLidar('COM3')
        
        try:
            while self.running:
                for scan in lidar.iter_scans():
                    if not self.running:
                        break
                        
                    scan_points = []
                    distances = []
                    
                    for (_, angle, distance) in scan:
                        # Filter out points beyond 4000mm if needed
                        if distance == 0 or distance > 4000:
                            continue
                        angle_rad = np.deg2rad(angle)
                        x = -distance * np.cos(angle_rad)
                        y = distance * np.sin(angle_rad)
                        point = rotate(np.array([[x, y]]), self.robot_theta)[0]
                        scan_points.append(point)
                        distances.append(distance)
                    
                    if scan_points:
                        scan_array = np.array(scan_points)
                        self.scan_points = scan_points
                        self.distances = distances
                        self.points_scatter.set_offsets(scan_array)
                        self.points_scatter.set_array(np.array(distances))
                    
                    # Update robot polygon
                    half_length = ROBOT_LENGTH / 2
                    half_width = ROBOT_WIDTH / 2
                    corners = np.array([
                        [-half_width, -half_length],
                        [-half_width,  half_length],
                        [ half_width,  half_length],
                        [ half_width, -half_length],
                    ])
                    rotated_corners = rotate(corners, self.robot_theta)
                    translated_corners = rotated_corners + self.robot_pos
                    self.robot_patch.set_xy(translated_corners)
                    
                    self.lidar_dot.center = (0, 0)
                    
                    self.canvas.draw()
                    self.root.update()
                    
        except Exception as e:
            print(f"Lidar error: {e}")
        finally:
            lidar.stop()
            lidar.disconnect()
    def stop(self):
        self.running = False
        if self.thread.is_alive():
            self.thread.join()

# --------------------------- GUI FUNCTIONS ----------------------------
def start_robot():
    global robot_running, robot_state
    robot_running = True
    robot_state = 1
    led_canvas.itemconfig(led_circle, fill="green")
    serialInst.write(f"0,0#0!0@{robot_state}$0\n".encode('utf-8'))

def stop_robot():
    global robot_running, robot_state
    robot_running = False
    robot_state = 0
    led_canvas.itemconfig(led_circle, fill="red")
    serialInst.write(f"0,0#0!0@{robot_state}$0\n".encode('utf-8'))

def camera():
    global show_camera
    show_camera = not show_camera
    cameraa_btn.config(text="fermer Camera" if show_camera else "Camera")

def toggle_camera():
    global show_filtered
    show_filtered = not show_filtered
    camera_btn.config(text="fermer filtre couleur" if show_filtered else "filtre couleur")

def elevate():
    global elevated, elevate_systeme
    elevated = not elevated
    if elevated:
        elevate_systeme = 1
        serialInst.write(f"0,0#0!0@0$1\n".encode('utf-8'))
        elevate_label.config(text="Élévateur Levé", style="Green.TLabel")
    else:
        elevate_systeme = 0
        serialInst.write(f"0,0#0!0@0$0\n".encode('utf-8'))
        elevate_label.config(text="Élévateur Baissé", style="Black.TLabel")

def select_depot(depot):
    global selected_depot, low, high
    selected_depot = depot
    if depot == 1:
        low = (32, 50, 61)
        high = (90, 255, 255)
    elif depot == 2:  # Yellow
        low = (15, 100, 150)
        high = (29, 255, 255)
    elif depot == 3:  # Blue
        low = (100, 102, 100)
        high = (120, 255, 255)
    depot_label.config(text=f"Dépôt sélectionné : {depot}")

# --------------------------- MAIN GUI ----------------------------
root = tk.Tk()
root.title("Robot Navigateur")
root.configure(bg="#f0f0f0")
root.resizable(False, False)
root.geometry("650x700+10+100")  # Increased height for LIDAR display

# Style ttk
style = ttk.Style()
style.configure("TButton", font=("Segoe UI", 11), padding=8)
style.configure("Green.TLabel", foreground="green", font=("Segoe UI", 11, "bold"))
style.configure("Black.TLabel", foreground="black", font=("Segoe UI", 11, "bold"))

# Frame principale
main_frame = ttk.Frame(root, padding=20)
main_frame.pack(expand=True)

# Control Frame
control_frame = ttk.Frame(main_frame)
control_frame.pack(fill=tk.X, pady=(0, 20))

# Robot Control
text_label1 = ttk.Label(control_frame, text="Contrôle du robot :", font=("Segoe UI", 12))
text_label1.grid(row=0, column=0, padx=10)

start_btn = ttk.Button(control_frame, text="Mise en marche", command=start_robot)
start_btn.grid(row=0, column=1, padx=10)

stop_btn = ttk.Button(control_frame, text="Arrêter", command=stop_robot)
stop_btn.grid(row=0, column=2, padx=10)

led_canvas = tk.Canvas(control_frame, width=40, height=40, highlightthickness=0, bg="#f0f0f0")
led_circle = led_canvas.create_oval(5, 5, 35, 35, fill="red")
led_canvas.grid(row=0, column=3, padx=10)

# Camera Control
text_label2 = ttk.Label(control_frame, text="Interface Graphique :", font=("Segoe UI", 12))
text_label2.grid(row=1, column=0, padx=10, pady=10)

cameraa_btn = ttk.Button(control_frame, text="fermer Camera", command=camera)
cameraa_btn.grid(row=1, column=1, padx=10, pady=10)

camera_btn = ttk.Button(control_frame, text="Filtre couleur", command=toggle_camera)
camera_btn.grid(row=1, column=2, padx=10, pady=10)

# Depot Selection
text_label3 = ttk.Label(control_frame, text="Sélection Dépôt :", font=("Segoe UI", 12))
text_label3.grid(row=2, column=0, padx=10, pady=10)

depot1_btn = ttk.Button(control_frame, text="Dépôt 1", command=lambda: select_depot(1))
depot1_btn.grid(row=2, column=1, padx=10, pady=10)

depot2_btn = ttk.Button(control_frame, text="Dépôt 2", command=lambda: select_depot(2))
depot2_btn.grid(row=2, column=2, padx=10, pady=10)

depot3_btn = ttk.Button(control_frame, text="Dépôt 3", command=lambda: select_depot(3))
depot3_btn.grid(row=2, column=3, padx=10, pady=10)

depot_label = ttk.Label(control_frame, text="Dépôt sélectionné : 1", font=("Segoe UI", 11, "bold"))
depot_label.grid(row=3, column=1, columnspan=2, pady=(5, 0))

# Elevation System
text_label4 = ttk.Label(control_frame, text="Système d'Élévation", font=("Segoe UI", 12))
text_label4.grid(row=4, column=0, padx=10, pady=10)

elevate_btn = ttk.Button(control_frame, text="Basculer", command=elevate)
elevate_btn.grid(row=4, column=1, padx=10, pady=10)

elevate_label = ttk.Label(control_frame, text="Élévateur Baissé", font=("Segoe UI", 11, "bold"))
elevate_label.grid(row=4, column=2)

battry_label = ttk.Label(control_frame, text="Battrie: 87%", font=("Segoe UI", 11))
battry_label.grid(row=4, column=3, columnspan=4, padx=(20, 0))

# LIDAR Display
lidar_frame = ttk.Frame(main_frame)
lidar_frame.pack(fill=tk.BOTH, expand=True)

lidar_visualizer = LidarVisualizer(lidar_frame)

# Start video processing thread
video_thread = threading.Thread(target=process_video)
video_thread.daemon = True
video_thread.start()

def on_closing():
    lidar_visualizer.stop()
    cap.release()
    cv2.destroyAllWindows()
    root.destroy()

root.protocol("WM_DELETE_WINDOW", on_closing)
root.mainloop()